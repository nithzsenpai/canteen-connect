const menuItem = localStorage.getItem("menuItem");

// Fetch the products from the Node.js backend
fetch("http://localhost:3000/products", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ category: menuItem }), // Send category in the request body
})
  .then((response) => response.json())
  .then((products) => {
    const productList = document.getElementById("product-list");

    // Loop through the products and display them
    products.forEach((product) => {
      const productCard = document.createElement("div");
      productCard.classList.add("product-card");

      productCard.innerHTML = `
              <img src="${product.image_url}" alt="${product.name}" class="product-image" />
              <div class="product-info">
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <p><strong>₹${product.price}</strong></p>
                <button class="add-to-cart-btn" data-id="${product.id}" data-name="${product.name}">Add to Cart</button>
              </div>
            `;

      productList.appendChild(productCard);
    });

    // Add event listeners to "Add to Cart" buttons
    const addToCartButtons = document.querySelectorAll(".add-to-cart-btn");
    addToCartButtons.forEach((button) => {
      button.addEventListener("click", (e) => {
        const productId = e.target.dataset.id;
        const productName = e.target.dataset.name;
        const email = localStorage.getItem("email");

        const data = {
          productId: productId,
          email: email,
        };
        // Send product to cart (you can implement the add-to-cart logic here)
        alert(`Product ${productName} added to cart!`);
        // Send a POST request to add the item to the cart
        fetch("http://localhost:3000/addToCart", {
          method: "POST",
          body: JSON.stringify(data),
          headers: {
            "Content-Type": "application/json",
          },
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.cartCount !== undefined) {
              // Update the cart count in the header
              updateCartIndicator(data.cartCount);
            }
          })
          .catch((error) => console.error("Error:", error));
      });
    });
  })
  .catch((error) => console.error("Error fetching products:", error));

function updateCartIndicator(cartCount) {
  const cartIndicator = document.querySelector("#cart-indicator"); // Assuming you have a div or span with id 'cart-indicator'
  if (cartIndicator) {
    cartIndicator.textContent = cartCount;
    localStorage.setItem("cardCount", cartCount);
  }
}
