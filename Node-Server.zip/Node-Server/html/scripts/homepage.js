window.onload = function () {
  const email = localStorage.getItem("email");
  if (email) {
    fetch("http://localhost:3000/getUserName", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email: email }),
    })
      .then((response) => response.json())
      .then((data) => {
        const userName = data.name;
        // Update the greeting title and message in the HTML
        const greetingTitleElement = document.getElementById("greetingTitle");
        const greetingMessageElement =
          document.getElementById("greetingMessage");

        greetingTitleElement.innerHTML = `Welcome Back, ${userName}! 🎉`;
        greetingMessageElement.innerHTML = `Enjoy your meal and tasty treats at Canteen Connect! 🍔🎉`;
      })
      .catch((error) => {
        console.error("Error fetching user name:", error);
      });
  } else {
    console.log("No email found in localStorage");
  }
};
