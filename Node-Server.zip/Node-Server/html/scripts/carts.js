const data = {
  email: localStorage.getItem("email"),
};

// Fetch cart items using fetch API
fetch("http://localhost:3000/cart", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify(data),
}) // The API endpoint for fetching cart items
  .then((response) => response.json())
  .then((cartItems) => {
    const cartContainer = document.getElementById("cart-items");
    const totalCostElement = document.getElementById("total-cost");
    let totalCost = 0;

    if (cartItems.length === 0) {
      cartContainer.innerHTML = "<p>Your cart is empty!</p>";
      totalCostElement.innerText = "0";
    } else {
      // Loop through the cart items and render them
      cartItems.forEach((item) => {
        cartContainer.innerHTML += `
          <div class="cart-item">
            <img src="${item.product_image}" alt="${item.name}" />
            <div>
              <h3>${item.name}</h3>
              <p>Price: ₹${item.price}</p>
              <p>Quantity: ${item.quantity}</p>
            </div>
          </div>
        `;

        // Calculate total cost (Price * Quantity)
        totalCost += item.price * item.quantity;
      });

      // Update the total cost on the page
      totalCostElement.innerText = totalCost;
    }
  })
  .catch((error) => {
    console.error("Error fetching cart items:", error);
    document.getElementById("cart-items").innerHTML =
      "<p>Error loading cart items.</p>";
    document.getElementById("total-cost").innerText = "0";
  });

const cartIndicator = document.querySelector("#cart-indicator");
cartIndicator.textContent = localStorage.getItem("cartCount");
