//All Elements
const signUpButton = document.getElementById("signUp");
const signInButton = document.getElementById("signIn");
const container = document.getElementById("container");
const signInForm = document.getElementById("sign-in-form");
const signUpForm = document.getElementById("sign-up-form");

//All Functions
function validateEmail(email) {
  const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  return regex.test(email);
}

//All EventHandlers
signUpButton.addEventListener("click", () => {
  container.classList.add("right-panel-active");
});

signInButton.addEventListener("click", () => {
  container.classList.remove("right-panel-active");
});

signInForm.addEventListener("submit", (e) => {
  e.preventDefault();
  // Get the form data
  const email = document.querySelector("#sign-in-email").value;
  const password = document.querySelector("#sign-in-password").value;

  const data = {
    email: email,
    password: password,
  };

  if (!validateEmail(email)) {
    alert("Invalid email address");
    return;
  }

  fetch("http://localhost:3000/signIn", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((response) => {
      if (response.ok) {
        // If the response is OK (success), redirect to the homepage
        localStorage.setItem("email", email);
        window.location.href = "homepage.html";
      } else {
        // If the response is not OK (failed login), show an error
        return response.text().then((text) => {
          alert(text || "Login failed. Please try again.");
        });
      }
    })
    .catch((error) => {
      // Handle network errors (e.g., if the server is unreachable)
      console.error("Error:", error);
      alert("An error occurred. Please try again later.");
    });
});

signUpForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const userName = document.querySelector("#sign-up-name").value;
  const email = document.querySelector("#sign-up-email").value;
  const password = document.querySelector("#sign-up-password").value;

  if (!validateEmail(email)) {
    alert("Invalid email address");
    return;
  }

  const userData = {
    name: userName,
    email: email,
    password: password,
  };

  fetch("http://localhost:3000/signUp", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(userData),
  })
    .then((response) => {
      if (response.ok) {
        localStorage.setItem("email", email);
        window.location.href = "homepage.html";
      } else {
        // If the response is not OK (failed login), show an error
        return response.text().then((text) => {
          alert(text || "Sign Up failed. Please try again.");
        });
      }
    })
    .catch((error) => {
      // Handle network errors (e.g., if the server is unreachable)
      console.error("Error:", error);
      alert("An error occurred. Please try again later.");
    });
});
