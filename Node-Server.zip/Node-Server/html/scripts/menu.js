const menuItem = document.querySelectorAll(".menu-item");

menuItem.forEach((item) => {
  item.addEventListener("click", () => {
    const menuItemText = item.querySelector("h4").innerText;
    localStorage.setItem("menuItem", menuItemText);
    window.location.href = "products.html";
  });
});
