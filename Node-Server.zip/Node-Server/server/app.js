const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const connection = mysql.createConnection({
  host: "192.168.0.127",
  user: "namita",
  password: "CanteenConnect",
  database: "canteen_db",
});

connection.connect((err) => {
  if (err) {
    console.error("Error connecting to the database:", err);
  } else {
    console.log("Connected to the MySQL database");
  }
});

// Test endpoint
app.get("/", (req, res) => {
  console.log("Server is running!");
  res.send("Server is running!");
});

app.post("/signIn", (req, res) => {
  const { email, password } = req.body;

  // Query to find the user by email
  const query = "SELECT * FROM users WHERE email = ?";

  connection.execute(query, [email], (err, results) => {
    if (err) {
      return res.status(500).send("Error querying database");
    }

    if (results.length === 0) {
      return res.status(401).send("User not found");
    }

    const user = results[0];

    if (user.email !== email || user.password !== password) {
      return res.status(401).send("Invalid email or password");
    } else {
      res.status(200).send("Login successful");
    }
  });
});

app.post("/signUp", (req, res) => {
  const { name, email, password } = req.body;

  // SQL query to insert data into users table
  const query = "INSERT INTO users (email, password, name) VALUES (?, ?, ?)";

  connection.execute(query, [email, password, name], (err, result) => {
    if (err) {
      console.error("Error inserting user:", err);
      return res.status(500).send("Database error");
    }

    // Return success response
    res.status(200).send("User registered successfully");
  });
});

app.post("/getUserName", (req, res) => {
  const { email } = req.body;

  // Query to find the user by email
  const query = "SELECT name FROM users WHERE email = ?";

  connection.execute(query, [email], (err, results) => {
    if (err) {
      return res.status(500).send("Error querying database");
    }

    if (results.length === 0) {
      return res.status(404).send("User not found");
    }

    const user = results[0];
    res.status(200).json(user);
  });
});

app.post("/products", (req, res) => {
  const { category } = req.body;
  // Query to get all products
  const query = "SELECT * FROM products WHERE category = ?";

  connection.query(query, [category], (err, results) => {
    if (err) {
      return res.status(500).send("Error querying database");
    }

    res.status(200).json(results);
  });
});

app.post("/addToCart", (req, res) => {
  const { productId, email } = req.body;

  // Step 1: Find the user_id based on the email
  const queryFindUser = "SELECT id FROM users WHERE email = ?";

  connection.execute(queryFindUser, [email], (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Error checking user information" });
    }

    if (results.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    // Step 2: Extract user_id from the results
    const userId = results[0].id;

    // Step 3: Check if the product is already in the cart
    const queryCheckProductInCart =
      "SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?";
    connection.execute(
      queryCheckProductInCart,
      [userId, productId],
      (err, cartResults) => {
        if (err) {
          return res.status(500).json({ error: "Error checking cart" });
        }

        if (cartResults.length > 0) {
          // If the product is already in the cart, update the quantity
          const updatedQuantity = cartResults[0].quantity + 1;
          const queryUpdateQuantity =
            "UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?";
          connection.execute(
            queryUpdateQuantity,
            [updatedQuantity, userId, productId],
            (err, updateResults) => {
              if (err) {
                return res
                  .status(500)
                  .json({ error: "Error updating cart quantity" });
              }

              // Step 4: Get updated cart count
              const queryCartCount =
                "SELECT COUNT(*) AS cartCount FROM cart WHERE user_id = ?";
              connection.execute(
                queryCartCount,
                [userId],
                (err, countResults) => {
                  if (err) {
                    return res
                      .status(500)
                      .json({ error: "Error fetching cart count" });
                  }

                  const cartCount = countResults[0].cartCount;
                  // Send back the updated cart count and success message
                  res.json({
                    message: "Product quantity updated in cart",
                    cartCount,
                  });
                }
              );
            }
          );
        } else {
          // If the product is not in the cart, insert a new row
          const queryInsertCart =
            "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)";
          connection.execute(
            queryInsertCart,
            [userId, productId],
            (err, insertResults) => {
              if (err) {
                return res
                  .status(500)
                  .json({ error: "Error adding item to cart" });
              }

              // Step 4: Get updated cart count
              const queryCartCount =
                "SELECT COUNT(*) AS cartCount FROM cart WHERE user_id = ?";
              connection.execute(
                queryCartCount,
                [userId],
                (err, countResults) => {
                  if (err) {
                    return res
                      .status(500)
                      .json({ error: "Error fetching cart count" });
                  }

                  const cartCount = countResults[0].cartCount;
                  // Send back the updated cart count and success message
                  res.json({ message: "Product added to cart", cartCount });
                }
              );
            }
          );
        }
      }
    );
  });
});

app.post("/cart", (req, res) => {
  const { email } = req.body;

  // Step 1: Find the user_id based on the email
  const queryFindUser = "SELECT id FROM users WHERE email = ?";

  connection.execute(queryFindUser, [email], (err, results) => {
    if (err) {
      return res.status(500).json({ error: "Error checking user information" });
    }

    if (results.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    // Step 2: Extract user_id from the results
    const userId = results[0].id;

    // Step 3: Get cart items
    const queryCartItems =
      "SELECT products.id, products.name, products.price, cart.quantity FROM products INNER JOIN cart ON products.id = cart.product_id WHERE cart.user_id = ?";

    connection.execute(queryCartItems, [userId], (err, results) => {
      if (err) {
        return res.status(500).json({ error: "Error fetching cart items" });
      }

      res.json(results);
    });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
